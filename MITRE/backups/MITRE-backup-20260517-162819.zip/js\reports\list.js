function escapeHtmlReport(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
}

function getReports() {
    try {
        return JSON.parse(localStorage.getItem('mitre-reports') || '[]');
    } catch {
        return [];
    }
}

function saveReports(reports) {
    localStorage.setItem('mitre-reports', JSON.stringify(reports));
}

function createNewReport() {
    const report = {
        id: 'rpt-' + Date.now(),
        name: 'Untitled Report',
        created: new Date().toISOString(),
        updated: new Date().toISOString(),
        layerId: state.currentLayer?.id || null,
        domain: state.currentDomain,
        version: state.currentVersion,
        sections: {
            'executive-summary': '',
            'scope': '',
            'coverage-image': null,
            'gap-analysis': '',
            'validation': '',
            'goals': '',
            'recommendations': '',
            'appendix': '',
        },
        changelog: [
            {
                date: new Date().toISOString(),
                author: 'User',
                action: 'Created report',
            }
        ],
        techniqueDetails: [],
    };
    
    const reports = getReports();
    reports.unshift(report);
    saveReports(reports);
    
    openReportEditor(report.id);
    showToast('Report created', 'success');
}

function renderReportsList() {
    const reports = getReports();
    const listEl = document.getElementById('reports-list');
    const emptyEl = document.getElementById('reports-empty');
    
    if (reports.length === 0) {
        listEl.innerHTML = '';
        emptyEl.classList.remove('d-none');
        return;
    }
    
    emptyEl.classList.add('d-none');
    listEl.innerHTML = reports.map(r => {
        const techCount = r.techniqueDetails?.length || 0;
        const updated = new Date(r.updated).toLocaleDateString();
        return `
            <div class="list-card report-card" data-id="${r.id}">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="card-title">${escapeHtmlReport(r.name)}</h6>
                        <div class="mb-2">
                            <span class="badge badge-id">${escapeHtmlReport(r.domain)}</span>
                            <span class="badge badge-type">${updated}</span>
                        </div>
                    </div>
                    <span class="badge bg-secondary">${techCount} techniques</span>
                </div>
                <p class="card-desc">${escapeHtmlReport(r.sections?.['executive-summary'] || '').substring(0, 100)}${(r.sections?.['executive-summary'] || '').length > 100 ? '...' : ''}</p>
            </div>
        `;
    }).join('');
    
    listEl.querySelectorAll('.report-card').forEach(card => {
        card.addEventListener('click', () => {
            openReportEditor(card.dataset.id);
        });
    });
}

document.getElementById('btn-create-report')?.addEventListener('click', createNewReport);
