function showLoading(show, text = 'Fetching STIX bundle...') {
    const overlay = document.getElementById('loading-overlay');
    const loadingText = document.getElementById('loading-text');
    loadingText.textContent = text;
    overlay.classList.toggle('d-none', !show);
}

function showLanding() {
    document.getElementById('landing-view').classList.remove('d-none');
    document.getElementById('workspace-view').classList.add('d-none');
    document.querySelector('.top-nav').classList.add('d-none');
    renderRecentLayers();
}

function showWorkspace() {
    document.getElementById('landing-view').classList.add('d-none');
    document.getElementById('workspace-view').classList.remove('d-none');
    document.querySelector('.top-nav').classList.remove('d-none');
}

function initTheme() {
    const saved = localStorage.getItem('attack-explorer-theme');
    if (saved === 'dark') {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        document.getElementById('theme-toggle').innerHTML = '<i class="bi bi-sun-fill"></i>';
    }
}

document.getElementById('theme-toggle').addEventListener('click', () => {
    const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    document.documentElement.setAttribute('data-bs-theme', isDark ? 'light' : 'dark');
    document.getElementById('theme-toggle').innerHTML = isDark
        ? '<i class="bi bi-moon-fill"></i>'
        : '<i class="bi bi-sun-fill"></i>';
    localStorage.setItem('attack-explorer-theme', isDark ? 'light' : 'dark');
});

document.querySelectorAll('[data-view]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        document.querySelectorAll('[data-view]').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        document.querySelectorAll('.view-section').forEach(s => s.classList.add('d-none'));
        document.getElementById(`${link.dataset.view}-view`).classList.remove('d-none');
        
        if (link.dataset.view === 'queries') {
            renderQueriesView();
        } else if (link.dataset.view === 'reports') {
            renderReportsList();
        }
    });
});

document.getElementById('nav-home').addEventListener('click', (e) => {
    e.preventDefault();
    saveCurrentLayer();
    showLanding();
});

document.getElementById('btn-create-new').addEventListener('click', () => {
    state.currentDomain = document.getElementById('domain-select').value;
    state.currentVersion = document.getElementById('version-select').value || 'master';
    state.expandedTechniques.clear();
    state.companyName = '';
    state.companyLogo = null;
    showWorkspace();
    loadSTIX(state.currentDomain, state.currentVersion);
});

document.getElementById('btn-view-matrix').addEventListener('click', () => {
    state.currentDomain = document.getElementById('domain-select').value;
    state.currentVersion = document.getElementById('version-select').value || 'master';
    state.expandedTechniques.clear();
    state.companyName = '';
    state.companyLogo = null;
    showWorkspace();
    loadSTIX(state.currentDomain, state.currentVersion);
});

document.getElementById('btn-import-layer').addEventListener('click', () => {
    document.getElementById('file-import').click();
});

document.getElementById('file-import').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
        try {
            const layerData = JSON.parse(ev.target.result);
            state.currentDomain = layerData.domain || 'enterprise-attack';
            state.currentVersion = layerData.attackVersion || 'master';
            state.companyName = layerData.companyName || '';
            state.companyLogo = layerData.companyLogo || null;
            state.autoColorRules = layerData.autoColorRules || state.autoColorRules;
            state.expandedTechniques.clear();
            document.getElementById('domain-select').value = state.currentDomain;
            document.getElementById('version-select').value = state.currentVersion;
            showWorkspace();
            loadSTIX(state.currentDomain, state.currentVersion, layerData);
        } catch (err) {
            showToast('Invalid layer file: ' + err.message, 'error');
        }
    };
    reader.readAsText(file);
    e.target.value = '';
});

document.getElementById('domain-select').addEventListener('change', (e) => {
    state.currentDomain = e.target.value;
    if (state.currentLayer) {
        loadSTIX(state.currentDomain, state.currentVersion || 'master', state.currentLayer);
    }
});

document.getElementById('version-select').addEventListener('change', (e) => {
    state.currentVersion = e.target.value;
    if (state.currentLayer) {
        loadSTIX(state.currentDomain, state.currentVersion, state.currentLayer);
    }
});

async function init() {
    initTheme();

    await fetchReleases();

    const lastVersion = localStorage.getItem('attack-explorer-last-version');
    if (lastVersion && state.releases.some(r => r.tag === lastVersion)) {
        state.currentVersion = lastVersion;
        document.getElementById('version-select').value = lastVersion;
    } else {
        state.currentVersion = state.releases[0]?.tag || 'master';
        document.getElementById('version-select').value = state.currentVersion;
    }

    // Restore current layer if exists
    const savedLayer = loadCurrentLayer();
    if (savedLayer) {
        state.currentDomain = localStorage.getItem('attack-explorer-current-domain') || 'enterprise-attack';
        state.currentVersion = localStorage.getItem('attack-explorer-current-version') || state.currentVersion;
        const savedExpanded = JSON.parse(localStorage.getItem('attack-explorer-expanded') || '[]');
        state.expandedTechniques = new Set(savedExpanded);

        document.getElementById('domain-select').value = state.currentDomain;
        document.getElementById('version-select').value = state.currentVersion;
        showWorkspace();
        await loadSTIX(state.currentDomain, state.currentVersion, savedLayer);
    } else {
        showLanding();
    }

    await checkForUpdates();
}

init();
