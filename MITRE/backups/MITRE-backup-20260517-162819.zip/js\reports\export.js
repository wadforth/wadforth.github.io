function exportReportPDF() {
    if (!state.currentReport) return;
    
    saveCurrentReport();
    
    const report = state.currentReport;
    const printWindow = window.open('', '_blank');
    
    const html = `
<!DOCTYPE html>
<html>
<head>
    <title>${escapeHtmlReport(report.name)}</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 2rem; color: #1a1a1a; line-height: 1.6; }
        h1 { color: #6366f1; border-bottom: 2px solid #6366f1; padding-bottom: 0.5rem; }
        h2 { color: #4f46e5; margin-top: 2rem; }
        .meta { color: #666; font-size: 0.9rem; margin-bottom: 2rem; }
        .section { margin-bottom: 2rem; page-break-inside: avoid; }
        .coverage-image { max-width: 100%; border: 1px solid #ddd; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin: 1rem 0; }
        th, td { border: 1px solid #ddd; padding: 0.5rem; text-align: left; font-size: 0.85rem; }
        th { background: #f5f5f5; font-weight: 600; }
        .color-swatch { display: inline-block; width: 16px; height: 16px; border-radius: 4px; vertical-align: middle; margin-right: 0.5rem; border: 1px solid #ddd; }
        .badge { display: inline-block; padding: 0.2em 0.5em; border-radius: 4px; font-size: 0.75rem; font-weight: 600; }
        .badge-id { background: #eef2ff; color: #6366f1; }
        @media print { body { margin: 1rem; } }
    </style>
</head>
<body>
    <h1>${escapeHtmlReport(report.name)}</h1>
    <div class="meta">
        Domain: ${escapeHtmlReport(report.domain)} | 
        Created: ${new Date(report.created).toLocaleDateString()} | 
        Updated: ${new Date(report.updated).toLocaleDateString()}
    </div>

    ${report.sections?.['executive-summary'] ? `
    <div class="section">
        <h2>Executive Summary</h2>
        <p>${escapeHtmlReport(report.sections['executive-summary']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.sections?.['scope'] ? `
    <div class="section">
        <h2>Scope Definition</h2>
        <p>${escapeHtmlReport(report.sections['scope']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.sections?.['coverage-image'] ? `
    <div class="section">
        <h2>Coverage Matrix</h2>
        <img src="${report.sections['coverage-image']}" class="coverage-image" alt="Coverage Matrix">
    </div>
    ` : ''}

    ${report.techniqueDetails?.length ? `
    <div class="section">
        <h2>Technique Level Detail</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Color</th>
                    <th>Score</th>
                    <th>Queries</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                ${report.techniqueDetails.map(t => `
                    <tr>
                        <td><span class="badge badge-id">${escapeHtmlReport(t.techniqueID)}</span></td>
                        <td>${t.color ? `<span class="color-swatch" style="background: ${t.color}"></span>` : '-'}</td>
                        <td>${t.score ? t.score + '/100' : '-'}</td>
                        <td>${t.queryCount || 0}</td>
                        <td>${escapeHtmlReport(t.comment || '').substring(0, 50)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>
    ` : ''}

    ${report.sections?.['gap-analysis'] ? `
    <div class="section">
        <h2>Gap Analysis & Prioritization</h2>
        <p>${escapeHtmlReport(report.sections['gap-analysis']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.sections?.['validation'] ? `
    <div class="section">
        <h2>Validation Evidence</h2>
        <p>${escapeHtmlReport(report.sections['validation']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.sections?.['goals'] ? `
    <div class="section">
        <h2>Goals & Objectives</h2>
        <p>${escapeHtmlReport(report.sections['goals']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.sections?.['recommendations'] ? `
    <div class="section">
        <h2>Recommendations</h2>
        <p>${escapeHtmlReport(report.sections['recommendations']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    ${report.changelog?.length ? `
    <div class="section">
        <h2>Change Log</h2>
        <table>
            <thead>
                <tr><th>Date</th><th>Author</th><th>Action</th></tr>
            </thead>
            <tbody>
                ${report.changelog.map(e => `
                    <tr>
                        <td>${new Date(e.date).toLocaleDateString()}</td>
                        <td>${escapeHtmlReport(e.author)}</td>
                        <td>${escapeHtmlReport(e.action)}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>
    ` : ''}

    ${report.sections?.['appendix'] ? `
    <div class="section">
        <h2>Appendix</h2>
        <p>${escapeHtmlReport(report.sections['appendix']).replace(/\n/g, '<br>')}</p>
    </div>
    ` : ''}

    <script>window.onload = () => { window.print(); };</script>
</body>
</html>
    `;
    
    printWindow.document.write(html);
    printWindow.document.close();
    showToast('PDF export opened in new window', 'info');
}

document.getElementById('btn-export-report-pdf')?.addEventListener('click', exportReportPDF);
