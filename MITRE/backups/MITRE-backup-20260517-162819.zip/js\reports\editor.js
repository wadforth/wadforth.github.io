function openReportEditor(reportId) {
    const reports = getReports();
    const report = reports.find(r => r.id === reportId);
    if (!report) return;
    
    state.currentReport = report;
    
    document.getElementById('report-editor-title').textContent = report.name;
    document.getElementById('report-editor-subtitle').textContent = `Created ${new Date(report.created).toLocaleDateString()} — ${report.domain}`;
    
    document.getElementById('report-executive-summary').value = report.sections?.['executive-summary'] || '';
    document.getElementById('report-scope').value = report.sections?.['scope'] || '';
    document.getElementById('report-gap-analysis').value = report.sections?.['gap-analysis'] || '';
    document.getElementById('report-validation').value = report.sections?.['validation'] || '';
    document.getElementById('report-goals').value = report.sections?.['goals'] || '';
    document.getElementById('report-recommendations').value = report.sections?.['recommendations'] || '';
    document.getElementById('report-appendix').value = report.sections?.['appendix'] || '';
    
    renderChangelog(report);
    renderTechniqueDetailList(report);
    renderCoverageStats();
    
    if (report.sections?.['coverage-image']) {
        document.getElementById('coverage-matrix-preview').innerHTML = `
            <img src="${report.sections['coverage-image']}" class="coverage-image-preview" alt="Coverage Matrix">
            <button class="btn btn-sm btn-outline-danger mt-2" id="btn-regenerate-coverage">
                <i class="bi bi-arrow-clockwise me-1"></i>Regenerate
            </button>
        `;
        document.getElementById('btn-regenerate-coverage')?.addEventListener('click', generateCoverageImage);
    }
    
    showView('report-editor-view');
    setActiveReportSection('executive-summary');
}

function saveCurrentReport() {
    if (!state.currentReport) return;
    
    const report = state.currentReport;
    report.name = document.getElementById('report-editor-title').textContent;
    report.updated = new Date().toISOString();
    report.sections = {
        ...report.sections,
        'executive-summary': document.getElementById('report-executive-summary').value,
        'scope': document.getElementById('report-scope').value,
        'gap-analysis': document.getElementById('report-gap-analysis').value,
        'validation': document.getElementById('report-validation').value,
        'goals': document.getElementById('report-goals').value,
        'recommendations': document.getElementById('report-recommendations').value,
        'appendix': document.getElementById('report-appendix').value,
    };
    
    const reports = getReports();
    const idx = reports.findIndex(r => r.id === report.id);
    if (idx >= 0) {
        reports[idx] = report;
        saveReports(reports);
        showToast('Report saved', 'success');
    }
}

function deleteCurrentReport() {
    if (!state.currentReport) return;
    
    if (confirm('Delete this report? This cannot be undone.')) {
        let reports = getReports();
        reports = reports.filter(r => r.id !== state.currentReport.id);
        saveReports(reports);
        state.currentReport = null;
        renderReportsList();
        showView('reports-view');
        showToast('Report deleted', 'success');
    }
}

function renderChangelog(report) {
    const container = document.getElementById('changelog-entries');
    const entries = report.changelog || [];
    
    container.innerHTML = entries.map((e, i) => `
        <div class="changelog-entry">
            <div class="changelog-date">${new Date(e.date).toLocaleDateString()}</div>
            <div class="changelog-author">${escapeHtmlReport(e.author)}</div>
            <div class="changelog-action">${escapeHtmlReport(e.action)}</div>
            <button class="btn btn-sm btn-ghost changelog-delete" data-idx="${i}"><i class="bi bi-x"></i></button>
        </div>
    `).join('');
    
    container.querySelectorAll('.changelog-delete').forEach(btn => {
        btn.addEventListener('click', () => {
            report.changelog.splice(parseInt(btn.dataset.idx), 1);
            renderChangelog(report);
        });
    });
}

function addChangelogEntry() {
    if (!state.currentReport) return;
    
    const action = prompt('Describe the change:');
    if (!action) return;
    
    state.currentReport.changelog.unshift({
        date: new Date().toISOString(),
        author: 'User',
        action,
    });
    
    renderChangelog(state.currentReport);
}

function renderTechniqueDetailList(report) {
    const container = document.getElementById('technique-detail-list');
    
    if (!state.currentLayer?.techniques?.length) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-info-circle"></i><p>No annotated techniques in current layer.</p></div>';
        return;
    }
    
    const annotated = state.currentLayer.techniques.filter(t => t.color || t.comment || t.score || t.queries?.length);
    
    if (annotated.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-info-circle"></i><p>No annotated techniques in current layer.</p></div>';
        return;
    }
    
    container.innerHTML = annotated.map(t => {
        const tech = state.techniques.find(x => x.external_references?.[0]?.external_id === t.techniqueID);
        const name = tech?.name || t.techniqueID;
        const queries = t.queries || [];
        return `
            <div class="technique-detail-entry">
                <div class="technique-detail-header">
                    <span class="badge badge-id">${escapeHtmlReport(t.techniqueID)}</span>
                    <span class="technique-detail-name">${escapeHtmlReport(name)}</span>
                </div>
                ${t.color ? `<div class="technique-detail-color"><span class="color-swatch" style="background: ${t.color}"></span> Color: ${t.color}</div>` : ''}
                ${t.score ? `<div class="technique-detail-score">Score: ${t.score}/100</div>` : ''}
                ${t.comment ? `<div class="technique-detail-comment">${escapeHtmlReport(t.comment)}</div>` : ''}
                ${queries.length ? `
                    <div class="technique-detail-queries">
                        <strong>${queries.length} quer${queries.length === 1 ? 'y' : 'ies'}:</strong>
                        ${queries.map(q => `<div class="query-ref"><span class="query-lang-badge ${q.language}">${q.language}</span> ${escapeHtmlReport(q.name)}</div>`).join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
    
    report.techniqueDetails = annotated.map(t => ({
        techniqueID: t.techniqueID,
        color: t.color,
        score: t.score,
        comment: t.comment,
        queryCount: t.queries?.length || 0,
    }));
}

function renderCoverageStats() {
    const container = document.getElementById('coverage-stats');
    
    if (!state.currentLayer?.techniques) {
        container.innerHTML = '';
        return;
    }
    
    const annotated = state.currentLayer.techniques.filter(t => t.color || t.queries?.length);
    const withQueries = state.currentLayer.techniques.filter(t => t.queries?.length > 0);
    const total = state.techniques.length;
    
    container.innerHTML = `
        <div class="stat-card"><div class="stat-value">${total}</div><div class="stat-label">Total Techniques</div></div>
        <div class="stat-card"><div class="stat-value">${annotated.length}</div><div class="stat-label">Annotated</div></div>
        <div class="stat-card"><div class="stat-value">${withQueries.length}</div><div class="stat-label">With Queries</div></div>
        <div class="stat-card"><div class="stat-value">${total > 0 ? Math.round((withQueries.length / total) * 100) : 0}%</div><div class="stat-label">Coverage</div></div>
    `;
}

async function generateCoverageImage() {
    const preview = document.getElementById('coverage-matrix-preview');
    const matrixEl = document.querySelector('.matrix-wrapper');
    
    if (!matrixEl) {
        showToast('Matrix not loaded', 'error');
        return;
    }
    
    preview.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary"></div><p class="text-muted small mt-2">Generating...</p></div>';
    
    try {
        const canvas = await html2canvas(matrixEl, {
            scale: 2,
            useCORS: true,
            backgroundColor: getComputedStyle(document.body).getPropertyValue('--surface-elevated').trim() || '#ffffff',
            logging: false,
        });
        
        const dataUrl = canvas.toDataURL('image/png', 0.9);
        state.currentReport.sections['coverage-image'] = dataUrl;
        
        preview.innerHTML = `
            <img src="${dataUrl}" class="coverage-image-preview" alt="Coverage Matrix">
            <button class="btn btn-sm btn-outline-danger mt-2" id="btn-regenerate-coverage">
                <i class="bi bi-arrow-clockwise me-1"></i>Regenerate
            </button>
        `;
        
        document.getElementById('btn-regenerate-coverage')?.addEventListener('click', generateCoverageImage);
        showToast('Coverage image generated', 'success');
    } catch (err) {
        preview.innerHTML = `
            <button class="btn btn-sm btn-primary" id="btn-generate-coverage-image">
                <i class="bi bi-camera me-1"></i>Generate Coverage Image
            </button>
        `;
        document.getElementById('btn-generate-coverage-image')?.addEventListener('click', generateCoverageImage);
        showToast('Failed to generate image: ' + err.message, 'error');
    }
}

function setActiveReportSection(sectionId) {
    document.querySelectorAll('#report-sections-tabs .nav-link').forEach(link => {
        link.classList.toggle('active', link.dataset.section === sectionId);
    });
    
    document.querySelectorAll('.report-section').forEach(section => {
        section.classList.add('d-none');
    });
    
    const target = document.getElementById(`section-${sectionId}`);
    if (target) target.classList.remove('d-none');
}

function showView(viewId) {
    document.querySelectorAll('.view-section').forEach(v => v.classList.add('d-none'));
    document.getElementById(viewId)?.classList.remove('d-none');
}

document.getElementById('btn-back-to-reports')?.addEventListener('click', () => {
    saveCurrentReport();
    renderReportsList();
    showView('reports-view');
});
document.getElementById('btn-save-report')?.addEventListener('click', saveCurrentReport);
document.getElementById('btn-delete-report')?.addEventListener('click', deleteCurrentReport);
document.getElementById('btn-add-changelog')?.addEventListener('click', addChangelogEntry);
document.getElementById('btn-generate-coverage-image')?.addEventListener('click', generateCoverageImage);

document.querySelectorAll('#report-sections-tabs .nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        setActiveReportSection(link.dataset.section);
    });
});

document.getElementById('report-editor-title')?.addEventListener('click', () => {
    const newName = prompt('Report name:', state.currentReport?.name);
    if (newName) {
        state.currentReport.name = newName;
        document.getElementById('report-editor-title').textContent = newName;
    }
});
