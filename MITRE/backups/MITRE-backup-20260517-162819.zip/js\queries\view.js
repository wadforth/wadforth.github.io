function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getAllQueries() {
    const queries = [];
    if (!state.currentLayer?.techniques) return queries;
    
    for (const tech of state.currentLayer.techniques) {
        if (tech.queries) {
            for (const q of tech.queries) {
                queries.push({ ...q, techniqueID: tech.techniqueID });
            }
        }
    }
    return queries;
}

function renderQueriesView() {
    const container = document.getElementById('queries-list');
    const searchInput = document.getElementById('query-search-input');
    const langFilter = document.getElementById('query-language-filter');
    
    const query = (searchInput?.value || '').toLowerCase().trim();
    const lang = langFilter?.value || 'all';
    
    let queries = getAllQueries();
    
    if (query) {
        queries = queries.filter(q =>
            q.name.toLowerCase().includes(query) ||
            q.query.toLowerCase().includes(query) ||
            (q.description || '').toLowerCase().includes(query) ||
            q.techniqueID.toLowerCase().includes(query)
        );
    }
    
    if (lang !== 'all') {
        queries = queries.filter(q => q.language === lang);
    }
    
    const techsWithQueries = new Set(queries.map(q => q.techniqueID));
    document.getElementById('queries-subtitle').textContent = 
        `${queries.length} quer${queries.length === 1 ? 'y' : 'ies'} across ${techsWithQueries.size} techniques`;
    
    if (queries.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="bi bi-code-slash"></i>
                <p>${query || lang !== 'all' ? 'No queries match your filters.' : 'No queries added yet. Right-click a technique to add one.'}</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = queries.map(q => {
        const tech = state.techniques.find(t => t.external_references?.[0]?.external_id === q.techniqueID);
        const techName = tech?.name || q.techniqueID;
        return `
            <div class="query-card" data-query-id="${q.id}">
                <div class="query-card-header">
                    <div>
                        <h6 class="query-card-title">${escapeHtml(q.name)}</h6>
                        <div class="query-meta mt-1">
                            <span class="query-lang-badge ${q.language}">${q.language}</span>
                            <span class="query-tech-ref">${q.techniqueID}</span>
                            <span class="text-muted small">${escapeHtml(techName)}</span>
                        </div>
                    </div>
                    <div class="query-card-actions">
                        <button class="btn btn-ghost btn-copy-query" data-query-id="${q.id}" title="Copy query">
                            <i class="bi bi-clipboard"></i>
                        </button>
                        <button class="btn btn-ghost btn-edit-query" data-query-id="${q.id}" title="Edit">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-ghost btn-delete-query" data-query-id="${q.id}" title="Delete">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="query-card-body">${escapeHtml(q.query)}</div>
                ${q.description ? `<p class="query-card-desc">${escapeHtml(q.description)}</p>` : ''}
                ${q.source ? `<div class="query-card-source">Source: ${escapeHtml(q.source)}</div>` : ''}
            </div>
        `;
    }).join('');
    
    container.querySelectorAll('.btn-copy-query').forEach(btn => {
        btn.addEventListener('click', () => {
            const q = queries.find(q => q.id === btn.dataset.queryId);
            if (q) {
                navigator.clipboard.writeText(q.query).then(() => showToast('Query copied to clipboard!', 'success'));
            }
        });
    });
    
    container.querySelectorAll('.btn-edit-query').forEach(btn => {
        btn.addEventListener('click', () => {
            const q = queries.find(q => q.id === btn.dataset.queryId);
            if (q) openQueryEditor(q);
        });
    });
    
    container.querySelectorAll('.btn-delete-query').forEach(btn => {
        btn.addEventListener('click', async () => {
            const q = queries.find(q => q.id === btn.dataset.queryId);
            if (!q) return;
            const confirmed = await showConfirm('Delete Query', `Delete "${q.name}"?`);
            if (confirmed) {
                deleteQuery(q.techniqueID, q.id);
                renderQueriesView();
                showToast('Query deleted', 'info');
            }
        });
    });
}

document.getElementById('query-search-input')?.addEventListener('input', renderQueriesView);
document.getElementById('query-language-filter')?.addEventListener('change', renderQueriesView);
